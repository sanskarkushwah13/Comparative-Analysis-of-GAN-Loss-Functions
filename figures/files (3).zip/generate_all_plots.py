"""
GAN Loss Function Comparison — Complete Plot Generator
======================================================
Uses REAL training data from your CSV files.

Usage:
    python generate_all_plots.py

Output:
    plots/  (10 PNG files, 300 DPI, publication-quality)
"""

import os, warnings
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D
from scipy.ndimage import uniform_filter1d

warnings.filterwarnings("ignore")
os.makedirs("plots", exist_ok=True)

matplotlib.rcParams.update({
    "font.family":        "DejaVu Sans",
    "axes.spines.top":    False,
    "axes.spines.right":  False,
    "axes.grid":          True,
    "grid.alpha":         0.22,
    "grid.linestyle":     "--",
    "grid.linewidth":     0.6,
    "figure.dpi":         150,
    "savefig.dpi":        300,
    "savefig.bbox":       "tight",
    "savefig.pad_inches": 0.15,
    "axes.titlesize":     13,
    "axes.labelsize":     11,
    "xtick.labelsize":    9,
    "ytick.labelsize":    9,
})

# ─── Color palette (one color per model, used everywhere) ────────────────────
PAL = {
    "STANDARD": "#E24B4A",
    "LSGAN":    "#EF9F27",
    "WGAN":     "#378ADD",
    "WGANGP":   "#1D9E75",
    "HINGE":    "#7F77DD",
    "HYBRID":   "#D85A30",
}
LABELS = {
    "STANDARD": "Standard GAN",
    "LSGAN":    "LSGAN",
    "WGAN":     "WGAN",
    "WGANGP":   "WGAN-GP",
    "HINGE":    "Hinge Loss",
    "HYBRID":   "Hybrid (Ours)",
}
ORDER = list(PAL.keys())

def col(key): return PAL[key]
def lbl(key): return LABELS[key]
def save(fig, name):
    p = f"plots/{name}.png"
    fig.savefig(p)
    plt.close(fig)
    print(f"  saved → {p}")

def smooth(arr, w=5):
    arr = np.array(arr, dtype=float)
    if len(arr) < w:
        return arr
    return uniform_filter1d(arr, size=w)

# ─── Load all CSVs ────────────────────────────────────────────────────────────
CIFAR    = pd.read_csv("csv/cifer_all_6.csv")
EURO150  = pd.read_csv("csv/euro_5229_graph.csv")
EURO_HYB = pd.read_csv("csv/euro_hybrid.csv")
CHEX_HYB = pd.read_csv("csv/hybridloss_cxpert.csv")

def get(df, exp, col_name):
    if exp == "HYBRID" and "dataset" in df.columns:
        return df[col_name].tolist()
    return df[df["Experiment"] == exp][col_name].tolist()

def get_fid(df, exp):
    if "dataset" in df.columns:
        sub = df[df["FID"].notna()]
    else:
        sub = df[(df["Experiment"] == exp) & df["FID"].notna()]
    return sub["Epoch"].tolist(), sub["FID"].tolist()

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 01 — FID curves over epochs, CIFAR-10
# ═══════════════════════════════════════════════════════════════════════════════
def plot_01_fid_curves_cifar():
    fig, ax = plt.subplots(figsize=(11, 5.5))
    for key in ORDER:
        ep, fid = get_fid(CIFAR, key)
        lw  = 2.5 if key == "HYBRID" else 1.8
        ls  = "--" if key == "HYBRID" else "-"
        ms  = 6   if key == "HYBRID" else 4
        ax.plot(ep, fid, color=col(key), lw=lw, ls=ls,
                marker="o", markersize=ms, label=lbl(key))
    ax.set_xlabel("Epoch")
    ax.set_ylabel("FID score  (↓ lower is better)")
    ax.set_title("FID Score over Training Epochs — CIFAR-10  (real data)")
    ax.legend(fontsize=9, ncol=2, framealpha=0.85)
    plt.tight_layout()
    save(fig, "01_fid_curves_cifar10")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 02 — FID curves over epochs, EuroSAT 150 epochs (all 6 models)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_02_fid_curves_eurosat():
    fig, ax = plt.subplots(figsize=(11, 5.5))
    for key in ["STANDARD", "LSGAN", "WGAN", "WGANGP", "HINGE"]:
        ep, fid = get_fid(EURO150, key)
        ax.plot(ep, fid, color=col(key), lw=1.8, marker="o",
                markersize=4, label=lbl(key))
    # Hybrid from separate file
    fid_eh = EURO_HYB[EURO_HYB["FID"].notna()]
    ax.plot(fid_eh["Epoch"].tolist(), fid_eh["FID"].tolist(),
            color=col("HYBRID"), lw=2.5, ls="--", marker="o",
            markersize=6, label=lbl("HYBRID"))
    ax.set_xlabel("Epoch")
    ax.set_ylabel("FID score  (↓ lower is better)")
    ax.set_title("FID Score over Training Epochs — EuroSAT  (real data)")
    ax.legend(fontsize=9, ncol=2, framealpha=0.85)
    plt.tight_layout()
    save(fig, "02_fid_curves_eurosat")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 03 — Generator loss curves, CIFAR-10
# ═══════════════════════════════════════════════════════════════════════════════
def plot_03_gloss_cifar():
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    axes = axes.flatten()
    for ax, key in zip(axes, ORDER):
        ep  = CIFAR[CIFAR["Experiment"] == key]["Epoch"].tolist()
        gl  = get(CIFAR, key, "G_Loss")
        dl  = get(CIFAR, key, "D_Loss")
        gl_s = smooth(gl)
        dl_s = smooth(dl)
        ax.plot(ep, gl_s, color=col(key), lw=2.0, label="Generator")
        ax.plot(ep, dl_s, color=col(key), lw=1.4, ls="--",
                alpha=0.6, label="Discriminator")
        ax.set_title(lbl(key), color=col(key), fontweight="bold")
        ax.set_xlabel("Epoch", fontsize=9)
        ax.set_ylabel("Loss", fontsize=9)
        ax.legend(fontsize=8, framealpha=0.7)
    fig.suptitle("Generator & Discriminator Loss Curves — CIFAR-10\n"
                 "Solid = Generator    Dashed = Discriminator",
                 fontsize=13, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "03_loss_curves_cifar10")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 04 — Generator loss curves, EuroSAT
# ═══════════════════════════════════════════════════════════════════════════════
def plot_04_gloss_eurosat():
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    axes = axes.flatten()
    dfs  = {k: EURO150[EURO150["Experiment"] == k] for k in
            ["STANDARD","LSGAN","WGAN","WGANGP","HINGE"]}
    dfs["HYBRID"] = EURO_HYB
    for ax, key in zip(axes, ORDER):
        sub = dfs[key]
        ep  = sub["Epoch"].tolist()
        gl_s = smooth(sub["G_Loss"].tolist())
        dl_s = smooth(sub["D_Loss"].tolist())
        ax.plot(ep, gl_s, color=col(key), lw=2.0, label="Generator")
        ax.plot(ep, dl_s, color=col(key), lw=1.4, ls="--",
                alpha=0.6, label="Discriminator")
        ax.set_title(lbl(key), color=col(key), fontweight="bold")
        ax.set_xlabel("Epoch", fontsize=9)
        ax.set_ylabel("Loss", fontsize=9)
        ax.legend(fontsize=8, framealpha=0.7)
    fig.suptitle("Generator & Discriminator Loss Curves — EuroSAT\n"
                 "Solid = Generator    Dashed = Discriminator",
                 fontsize=13, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "04_loss_curves_eurosat")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 05 — Mode Variance over epochs, CIFAR-10
# ═══════════════════════════════════════════════════════════════════════════════
def plot_05_modevar_cifar():
    fig, ax = plt.subplots(figsize=(11, 5.5))
    for key in ORDER:
        ep = CIFAR[CIFAR["Experiment"] == key]["Epoch"].tolist()
        mv = smooth(get(CIFAR, key, "ModeVar"), w=7)
        lw = 2.5 if key == "HYBRID" else 1.8
        ls = "--" if key == "HYBRID" else "-"
        ax.plot(ep, mv, color=col(key), lw=lw, ls=ls, label=lbl(key))
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Mode Variance  (↑ higher = more diverse)")
    ax.set_title("Mode Variance over Training — CIFAR-10  (real data)")
    ax.legend(fontsize=9, ncol=2, framealpha=0.85)
    plt.tight_layout()
    save(fig, "05_modevar_curves_cifar10")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 06 — Mode Variance over epochs, EuroSAT
# ═══════════════════════════════════════════════════════════════════════════════
def plot_06_modevar_eurosat():
    fig, ax = plt.subplots(figsize=(11, 5.5))
    dfs = {k: EURO150[EURO150["Experiment"] == k] for k in
           ["STANDARD","LSGAN","WGAN","WGANGP","HINGE"]}
    dfs["HYBRID"] = EURO_HYB
    for key in ORDER:
        sub = dfs[key]
        ep  = sub["Epoch"].tolist()
        mv  = smooth(sub["ModeVar"].tolist(), w=7)
        lw  = 2.5 if key == "HYBRID" else 1.8
        ls  = "--" if key == "HYBRID" else "-"
        ax.plot(ep, mv, color=col(key), lw=lw, ls=ls, label=lbl(key))
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Mode Variance  (↑ higher = more diverse)")
    ax.set_title("Mode Variance over Training — EuroSAT  (real data)")
    ax.legend(fontsize=9, ncol=2, framealpha=0.85)
    plt.tight_layout()
    save(fig, "06_modevar_curves_eurosat")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 07 — Best FID bar chart (CIFAR + EuroSAT + CheXpert)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_07_best_fid_bar():
    best_cifar = {}
    for k in ORDER:
        _, fid = get_fid(CIFAR, k)
        best_cifar[k] = min(fid)

    best_euro = {}
    for k in ["STANDARD","LSGAN","WGAN","WGANGP","HINGE"]:
        _, fid = get_fid(EURO150, k)
        best_euro[k] = min(fid)
    fid_eh = EURO_HYB[EURO_HYB["FID"].notna()]["FID"]
    best_euro["HYBRID"] = float(fid_eh.min())

    best_chex = {k: None for k in ORDER}
    fid_cx = CHEX_HYB[CHEX_HYB["FID"].notna()]["FID"]
    best_chex["HYBRID"] = float(fid_cx.min())

    x = np.arange(len(ORDER))
    w = 0.26
    fig, ax = plt.subplots(figsize=(13, 6))

    b1 = ax.bar(x - w, [best_cifar[k] for k in ORDER], w,
                color=[col(k) for k in ORDER],
                edgecolor="white", linewidth=0.8,
                label="CIFAR-10", zorder=3)
    b2 = ax.bar(x,     [best_euro[k]  for k in ORDER], w,
                color=[col(k) for k in ORDER], alpha=0.6,
                edgecolor="white", linewidth=0.8, hatch="///",
                label="EuroSAT", zorder=3)
    b3 = ax.bar(x + w, [best_chex[k] if best_chex[k] else 0 for k in ORDER], w,
                color=[col(k) for k in ORDER], alpha=0.35,
                edgecolor="white", linewidth=0.8, hatch="xxx",
                label="CheXpert (Hybrid only)", zorder=3)

    for bar in list(b1) + list(b2) + list(b3):
        v = bar.get_height()
        if v > 1:
            ax.text(bar.get_x() + bar.get_width()/2,
                    v + 1.5, f"{v:.1f}",
                    ha="center", va="bottom",
                    fontsize=7.5, color="#444")

    ax.set_xticks(x)
    ax.set_xticklabels([lbl(k) for k in ORDER], rotation=18, ha="right")
    ax.set_ylabel("Best FID  (↓ lower is better)")
    ax.set_title("Best FID Score by Loss Function — All Datasets  (real data)")
    handles = [
        Line2D([0],[0], color="#666", lw=8, alpha=1.0,   label="CIFAR-10"),
        Line2D([0],[0], color="#666", lw=8, alpha=0.6,   label="EuroSAT (hatched)"),
        Line2D([0],[0], color="#666", lw=8, alpha=0.35,  label="CheXpert (Hybrid only)"),
    ]
    ax.legend(handles=handles, fontsize=9, framealpha=0.9)
    plt.tight_layout()
    save(fig, "07_best_fid_all_datasets")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 08 — Mode Variance bar comparison (CIFAR vs EuroSAT, final epoch)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_08_modevar_bar():
    mv_cifar = {}
    mv_euro  = {}
    for k in ORDER:
        mv_cifar[k] = CIFAR[CIFAR["Experiment"]==k]["ModeVar"].iloc[-1]
    for k in ["STANDARD","LSGAN","WGAN","WGANGP","HINGE"]:
        mv_euro[k] = EURO150[EURO150["Experiment"]==k]["ModeVar"].iloc[-1]
    mv_euro["HYBRID"] = EURO_HYB["ModeVar"].iloc[-1]

    x = np.arange(len(ORDER))
    w = 0.35
    fig, ax = plt.subplots(figsize=(12, 5.5))
    b1 = ax.bar(x - w/2, [mv_cifar[k] for k in ORDER], w,
                color=[col(k) for k in ORDER],
                edgecolor="white", linewidth=0.8,
                label="CIFAR-10", zorder=3)
    b2 = ax.bar(x + w/2, [mv_euro[k]  for k in ORDER], w,
                color=[col(k) for k in ORDER], alpha=0.55,
                edgecolor="white", linewidth=0.8, hatch="///",
                label="EuroSAT", zorder=3)
    for bar in list(b1) + list(b2):
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + 0.003,
                f"{bar.get_height():.3f}",
                ha="center", va="bottom", fontsize=7.5, color="#444")
    ax.set_xticks(x)
    ax.set_xticklabels([lbl(k) for k in ORDER], rotation=18, ha="right")
    ax.set_ylabel("Mode Variance  (↑ higher = more diverse)")
    ax.set_title("Final Mode Variance — CIFAR-10 vs EuroSAT  (real data)")
    handles = [
        Line2D([0],[0], color="#666", lw=8, alpha=1.0,  label="CIFAR-10"),
        Line2D([0],[0], color="#666", lw=8, alpha=0.55, label="EuroSAT (hatched)"),
    ]
    ax.legend(handles=handles, fontsize=9, framealpha=0.9)
    plt.tight_layout()
    save(fig, "08_modevar_bar_comparison")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 09 — Quality-Diversity Scatter (FID vs Mode Variance, CIFAR-10)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_09_pareto_scatter():
    best_fid = {}
    for k in ORDER:
        _, fid = get_fid(CIFAR, k)
        best_fid[k] = min(fid)
    final_mv = {k: CIFAR[CIFAR["Experiment"]==k]["ModeVar"].iloc[-1]
                for k in ORDER}

    fig, ax = plt.subplots(figsize=(9, 6))
    for k in ORDER:
        sz  = 280 if k == "HYBRID" else 120
        mrk = "*" if k == "HYBRID" else "o"
        ax.scatter(best_fid[k], final_mv[k],
                   color=col(k), s=sz, marker=mrk,
                   edgecolors="white", linewidths=0.8, zorder=5)
        offset = (5, 5) if k != "STANDARD" else (5, -12)
        ax.annotate(lbl(k), (best_fid[k], final_mv[k]),
                    textcoords="offset points", xytext=offset,
                    fontsize=9, color=col(k), fontweight="bold")

    ax.set_xlabel("Best FID  (← lower is better)")
    ax.set_ylabel("Final Mode Variance  (↑ higher = more diverse)")
    ax.set_title("Quality–Diversity Trade-off — CIFAR-10  (real data)\n"
                 "Ideal position: bottom-right corner  ★ = Hybrid")
    plt.tight_layout()
    save(fig, "09_pareto_scatter_cifar10")

# ═══════════════════════════════════════════════════════════════════════════════
# PLOT 10 — CheXpert Hybrid: G/D Loss + FID + ModeVar (3-panel)
# ═══════════════════════════════════════════════════════════════════════════════
def plot_10_chexpert_hybrid():
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    ep   = CHEX_HYB["Epoch"].tolist()
    gl_s = smooth(CHEX_HYB["G_Loss"].tolist(), w=9)
    dl_s = smooth(CHEX_HYB["D_Loss"].tolist(), w=9)
    mv_s = smooth(CHEX_HYB["ModeVar"].tolist(), w=7)
    fid_rows = CHEX_HYB[CHEX_HYB["FID"].notna()]

    # Panel A — Loss curves
    axes[0].plot(ep, gl_s, color=col("HYBRID"), lw=2, label="Generator")
    axes[0].plot(ep, dl_s, color=col("HYBRID"), lw=1.5, ls="--",
                 alpha=0.6, label="Discriminator")
    axes[0].set_title("A  Loss curves", fontweight="bold")
    axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
    axes[0].legend(fontsize=9)

    # Panel B — FID
    axes[1].plot(fid_rows["Epoch"], fid_rows["FID"],
                 color=col("HYBRID"), lw=2.2, marker="o", markersize=6)
    axes[1].axhline(fid_rows["FID"].min(), color=col("HYBRID"),
                    lw=1, ls=":", alpha=0.6,
                    label=f"Best FID = {fid_rows['FID'].min():.2f}")
    axes[1].set_title("B  FID score", fontweight="bold")
    axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("FID")
    axes[1].legend(fontsize=9)

    # Panel C — ModeVar
    axes[2].plot(ep, mv_s, color=col("HYBRID"), lw=2)
    axes[2].set_title("C  Mode Variance", fontweight="bold")
    axes[2].set_xlabel("Epoch"); axes[2].set_ylabel("Mode Variance")

    fig.suptitle("Hybrid Loss on CheXpert  (100 epochs, real data)",
                 fontsize=13, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "10_chexpert_hybrid_analysis")

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("Generating all 10 plots from real CSV data...\n")
    plot_01_fid_curves_cifar()
    plot_02_fid_curves_eurosat()
    plot_03_gloss_cifar()
    plot_04_gloss_eurosat()
    plot_05_modevar_cifar()
    plot_06_modevar_eurosat()
    plot_07_best_fid_bar()
    plot_08_modevar_bar()
    plot_09_pareto_scatter()
    plot_10_chexpert_hybrid()
    print("\nAll 10 plots saved to ./plots/")
