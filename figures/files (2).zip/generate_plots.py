"""
Comparative Analysis of GAN Loss Functions
==========================================
Run:  python generate_plots.py
Outputs saved to ./plots/
"""

import os, warnings
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D

warnings.filterwarnings("ignore")
matplotlib.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.25,
    "grid.linestyle": "--",
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.15,
})

os.makedirs("plots", exist_ok=True)

# ──────────────────────────────────────────────────────────────────────────────
# COLOR PALETTE  (one color per loss function, consistent across ALL plots)
# ──────────────────────────────────────────────────────────────────────────────
PALETTE = {
    "Standard GAN": "#E24B4A",
    "LSGAN":        "#EF9F27",
    "WGAN":         "#378ADD",
    "WGAN-GP":      "#1D9E75",
    "Hinge Loss":   "#7F77DD",
    "Hybrid":       "#D85A30",
}
LOSS_ORDER = list(PALETTE.keys())
COLORS     = [PALETTE[k] for k in LOSS_ORDER]

# ──────────────────────────────────────────────────────────────────────────────
# HARD-CODED SUMMARY RESULTS  (from your Chapter-4 tables)
# Replace with CSV reads once you share the files
# ──────────────────────────────────────────────────────────────────────────────
CIFAR10 = {
    "Loss":       LOSS_ORDER,
    "Best_FID":   [363.74, 161.46, 102.89,  58.86, 185.02,  61.34],
    "Mode_Var":   [0.0470, 0.1551, 0.2866,  0.2420, 0.0736, 0.2980],
    "Final_LG":   [11.7468, 0.5197, 0.0624, 1204.01, 4.4412, 987.23],
    "Final_LD":   [0.0000, 0.0242, -0.1315, -4.2752, 0.0653, -3.891],
    "Stability":  [1, 2, 3, 5, 3, 5],   # encoded: 1=Poor 2=Mod 3=Good 5=Excellent
}
EUROSAT = {
    "Loss":       LOSS_ORDER,
    "Best_FID":   [40.90,  39.91, 102.88,  95.55,  48.88,  43.17],
    "Mode_Var":   [0.0429, 0.0580, 0.1188, 0.0786, 0.0671, 0.0921],
    "Final_LG":   [6.6873, 0.4821, 0.0103, 583.405, 4.4938, 512.41],
    "Final_LD":   [0.0593, 0.0471, -0.0907, 60.891, 0.1319, 42.31],
    "Stability":  [1, 2, 3, 5, 3, 5],
}
df_c = pd.DataFrame(CIFAR10)
df_e = pd.DataFrame(EUROSAT)


# ══════════════════════════════════════════════════════════════════════════════
# HELPER
# ══════════════════════════════════════════════════════════════════════════════
def bar_colors(df):
    return [PALETTE[l] for l in df["Loss"]]

def save(fig, name):
    path = f"plots/{name}.png"
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved → {path}")


# ══════════════════════════════════════════════════════════════════════════════
# PLOT 1 — FID Bar Chart (side-by-side datasets)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fid_bar():
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), sharey=False)
    for ax, df, title in zip(axes, [df_c, df_e], ["CIFAR-10", "EuroSAT"]):
        bars = ax.bar(df["Loss"], df["Best_FID"],
                      color=bar_colors(df), edgecolor="white",
                      linewidth=0.8, width=0.6, zorder=3)
        for bar, val in zip(bars, df["Best_FID"]):
            ax.text(bar.get_x() + bar.get_width()/2,
                    bar.get_height() + max(df["Best_FID"])*0.015,
                    f"{val:.1f}", ha="center", va="bottom",
                    fontsize=8.5, fontweight="bold", color="#444")
        ax.set_title(title, fontsize=13, fontweight="bold", pad=10)
        ax.set_ylabel("Best FID  (↓ lower is better)", fontsize=10)
        ax.set_xticklabels(df["Loss"], rotation=25, ha="right", fontsize=9)
        ax.set_ylim(0, max(df["Best_FID"]) * 1.18)
    fig.suptitle("Best FID Score by Loss Function", fontsize=15, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "01_fid_bar")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 2 — Mode Variance Bar Chart
# ══════════════════════════════════════════════════════════════════════════════
def plot_mode_var_bar():
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    for ax, df, title in zip(axes, [df_c, df_e], ["CIFAR-10", "EuroSAT"]):
        bars = ax.bar(df["Loss"], df["Mode_Var"],
                      color=bar_colors(df), edgecolor="white",
                      linewidth=0.8, width=0.6, zorder=3)
        for bar, val in zip(bars, df["Mode_Var"]):
            ax.text(bar.get_x() + bar.get_width()/2,
                    bar.get_height() + max(df["Mode_Var"])*0.02,
                    f"{val:.3f}", ha="center", va="bottom",
                    fontsize=8.5, fontweight="bold", color="#444")
        ax.set_title(title, fontsize=13, fontweight="bold", pad=10)
        ax.set_ylabel("Mode Variance  (↑ higher = more diverse)", fontsize=10)
        ax.set_xticklabels(df["Loss"], rotation=25, ha="right", fontsize=9)
        ax.set_ylim(0, max(df["Mode_Var"]) * 1.2)
    fig.suptitle("Mode Variance (Diversity) by Loss Function", fontsize=15, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "02_mode_variance_bar")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 3 — FID vs Mode Variance Scatter (Pareto plot)
# ══════════════════════════════════════════════════════════════════════════════
def plot_pareto_scatter():
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    for ax, df, title in zip(axes, [df_c, df_e], ["CIFAR-10", "EuroSAT"]):
        for _, row in df.iterrows():
            c   = PALETTE[row["Loss"]]
            sz  = 220 if row["Loss"] == "Hybrid" else 130
            mrk = "*" if row["Loss"] == "Hybrid" else "o"
            ax.scatter(row["Best_FID"], row["Mode_Var"],
                       color=c, s=sz, marker=mrk,
                       edgecolors="white", linewidths=0.8, zorder=5)
            ax.annotate(row["Loss"],
                        (row["Best_FID"], row["Mode_Var"]),
                        textcoords="offset points", xytext=(6, 4),
                        fontsize=8, color=c, fontweight="bold")
        ax.set_xlabel("Best FID  (← lower is better)", fontsize=10)
        ax.set_ylabel("Mode Variance  (↑ higher is better)", fontsize=10)
        ax.set_title(title, fontsize=13, fontweight="bold", pad=10)
        # ideal region annotation
        xlim = ax.get_xlim(); ylim = ax.get_ylim()
        ax.annotate("Ideal\nregion →", xy=(xlim[0]+5, ylim[1]-0.02),
                    fontsize=8, color="gray", style="italic")
    fig.suptitle("Quality–Diversity Trade-off  (FID vs Mode Variance)",
                 fontsize=15, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "03_pareto_fid_vs_diversity")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 4 — Grouped Bar: FID across both datasets
# ══════════════════════════════════════════════════════════════════════════════
def plot_grouped_fid():
    x     = np.arange(len(LOSS_ORDER))
    width = 0.35
    fig, ax = plt.subplots(figsize=(13, 6))
    b1 = ax.bar(x - width/2, df_c["Best_FID"], width,
                label="CIFAR-10", color=COLORS,
                edgecolor="white", linewidth=0.8, zorder=3)
    b2 = ax.bar(x + width/2, df_e["Best_FID"], width,
                label="EuroSAT",  color=COLORS,
                edgecolor="white", linewidth=0.8, alpha=0.55, zorder=3,
                hatch="///")
    for bar in list(b1) + list(b2):
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + 3,
                f"{bar.get_height():.0f}",
                ha="center", va="bottom", fontsize=7.5, color="#333")
    ax.set_xticks(x)
    ax.set_xticklabels(LOSS_ORDER, rotation=20, ha="right", fontsize=10)
    ax.set_ylabel("Best FID  (↓ lower is better)", fontsize=11)
    ax.set_title("Cross-Dataset FID Comparison", fontsize=15, fontweight="bold")
    # custom legend
    handles = [
        Line2D([0],[0], color="gray", lw=8, alpha=1.0, label="CIFAR-10"),
        Line2D([0],[0], color="gray", lw=8, alpha=0.5, label="EuroSAT (hatched)"),
    ]
    ax.legend(handles=handles, fontsize=10, framealpha=0.9)
    plt.tight_layout()
    save(fig, "04_grouped_fid_cross_dataset")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 5 — Radar / Spider Chart
# ══════════════════════════════════════════════════════════════════════════════
def plot_radar():
    categories = ["FID\n(inv)", "Mode\nVar", "Stability", "Comp.\nEff."]
    N = len(categories)
    angles = np.linspace(0, 2*np.pi, N, endpoint=False).tolist()
    angles += angles[:1]

    # Normalise metrics to [0,1]; FID inverted (lower FID = higher score)
    def norm(arr, invert=False):
        mn, mx = min(arr), max(arr)
        vals = [(v - mn)/(mx - mn) for v in arr]
        if invert:
            vals = [1 - v for v in vals]
        return vals

    fid_n    = norm(df_c["Best_FID"], invert=True)
    mvar_n   = norm(df_c["Mode_Var"])
    stab_n   = norm(df_c["Stability"])
    # computational efficiency: ncritic=1 → efficient; ncritic=5+GP → expensive
    comp_eff = [1.0, 1.0, 0.6, 0.2, 1.0, 0.3]

    fig, ax = plt.subplots(figsize=(8, 8),
                           subplot_kw=dict(polar=True))
    ax.set_facecolor("#f8f8f8")
    for i, loss in enumerate(LOSS_ORDER):
        vals = [fid_n[i], mvar_n[i], stab_n[i], comp_eff[i]]
        vals += vals[:1]
        lw  = 2.5 if loss == "Hybrid" else 1.5
        ls  = "-"  if loss == "Hybrid" else "--"
        al  = 1.0  if loss == "Hybrid" else 0.7
        ax.plot(angles, vals, color=PALETTE[loss],
                linewidth=lw, linestyle=ls, alpha=al, label=loss)
        ax.fill(angles, vals, color=PALETTE[loss], alpha=0.06)

    ax.set_thetagrids(np.degrees(angles[:-1]), categories, fontsize=11)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0.25","0.50","0.75","1.00"], fontsize=8, color="gray")
    ax.set_title("Multi-Metric Radar — CIFAR-10\n(Hybrid highlighted)",
                 fontsize=13, fontweight="bold", pad=20)
    ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.1),
              fontsize=9, framealpha=0.9)
    plt.tight_layout()
    save(fig, "05_radar_chart")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 6 — Stability Heatmap (both datasets)
# ══════════════════════════════════════════════════════════════════════════════
def plot_heatmap():
    stab_labels = {1:"Poor", 2:"Moderate", 3:"Good", 5:"Excellent"}
    datasets = ["CIFAR-10", "EuroSAT"]
    matrix   = np.array([df_c["Stability"].values,
                         df_e["Stability"].values], dtype=float)

    fig, ax = plt.subplots(figsize=(11, 3.5))
    cmap = matplotlib.colormaps.get_cmap("RdYlGn")
    im = ax.imshow(matrix, cmap=cmap, vmin=1, vmax=5, aspect="auto")

    ax.set_xticks(range(len(LOSS_ORDER)))
    ax.set_xticklabels(LOSS_ORDER, fontsize=11)
    ax.set_yticks(range(len(datasets)))
    ax.set_yticklabels(datasets, fontsize=11)

    for i in range(len(datasets)):
        for j in range(len(LOSS_ORDER)):
            v   = int(matrix[i, j])
            txt = stab_labels[v]
            col = "white" if v >= 4 else "black"
            ax.text(j, i, txt, ha="center", va="center",
                    fontsize=10, fontweight="bold", color=col)

    ax.set_title("Training Stability Heatmap", fontsize=14, fontweight="bold", pad=12)
    cbar = plt.colorbar(im, ax=ax, orientation="vertical", pad=0.02)
    cbar.set_ticks([1, 2, 3, 5])
    cbar.set_ticklabels(["Poor","Moderate","Good","Excellent"])
    cbar.ax.tick_params(labelsize=9)
    plt.tight_layout()
    save(fig, "06_stability_heatmap")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 7 — FID Ranking Table (visual)
# ══════════════════════════════════════════════════════════════════════════════
def plot_ranking_table():
    c_rank = df_c.sort_values("Best_FID").reset_index(drop=True)
    e_rank = df_e.sort_values("Best_FID").reset_index(drop=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    for ax, df_r, title in zip(axes, [c_rank, e_rank], ["CIFAR-10", "EuroSAT"]):
        ax.axis("off")
        cols = ["Rank", "Loss Function", "Best FID", "Mode Var.", "Stability"]
        stab_map = {1:"Poor", 2:"Moderate", 3:"Good", 5:"Excellent"}
        rows = []
        for i, row in df_r.iterrows():
            rows.append([
                f"#{i+1}",
                row["Loss"],
                f"{row['Best_FID']:.2f}",
                f"{row['Mode_Var']:.4f}",
                stab_map[row["Stability"]],
            ])
        tbl = ax.table(cellText=rows, colLabels=cols,
                       loc="center", cellLoc="center")
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(10)
        tbl.scale(1.2, 1.8)
        # header styling
        for j in range(len(cols)):
            tbl[0, j].set_facecolor("#2C2C2A")
            tbl[0, j].set_text_props(color="white", fontweight="bold")
        # row colouring
        for i, row in df_r.iterrows():
            fc = "#E1F5EE" if row["Loss"] == "Hybrid" else \
                 "#FFF8E7" if i == 0 else "white"
            for j in range(len(cols)):
                tbl[i+1, j].set_facecolor(fc)
        ax.set_title(title, fontsize=13, fontweight="bold", pad=15)
    fig.suptitle("FID Ranking Table (sorted best → worst)",
                 fontsize=15, fontweight="bold", y=1.02)
    plt.tight_layout()
    save(fig, "07_ranking_table")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 8 — Loss Curves (simulated from your training data)
#          Replace np.load lines with your actual CSV once uploaded
# ══════════════════════════════════════════════════════════════════════════════
def plot_loss_curves_simulated():
    """
    Generates plausible loss curves based on your reported final values.
    Replace with:
        df = pd.read_csv("csv/cifer_all_6.csv")
    and adjust column names accordingly once you upload the CSVs.
    """
    epochs = np.arange(1, 101)
    np.random.seed(42)

    def smooth(arr, w=7):
        return np.convolve(arr, np.ones(w)/w, mode="same")

    # (start_G, end_G, start_D, end_D)
    params = {
        "Standard GAN": (3.0, 11.75,  0.7,  0.00),
        "LSGAN":        (1.5,  0.52,  0.6,  0.024),
        "WGAN":         (0.5,  0.062, -0.05, -0.132),
        "WGAN-GP":      (800, 1204.0, -2.0, -4.275),
        "Hinge Loss":   (2.0,  4.44,  0.3,  0.065),
        "Hybrid":       (600,  987.2, -1.8, -3.891),
    }

    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    axes = axes.flatten()

    for ax, (loss, (sg, eg, sd, ed)) in zip(axes, params.items()):
        t = epochs / 100
        g_curve = sg + (eg - sg) * t**0.6 + np.random.randn(100)*abs(eg-sg)*0.04
        d_curve = sd + (ed - sd) * t**0.7 + np.random.randn(100)*abs(ed-sd)*0.05
        g_s = smooth(g_curve)
        d_s = smooth(d_curve)
        c = PALETTE[loss]
        ax.plot(epochs, g_s, color=c,       lw=2,   label="Generator")
        ax.plot(epochs, d_s, color=c, lw=1.5, ls="--", alpha=0.6, label="Discriminator")
        ax.set_title(loss, fontsize=11, fontweight="bold", color=c)
        ax.set_xlabel("Epoch", fontsize=9)
        ax.set_ylabel("Loss", fontsize=9)
        ax.tick_params(labelsize=8)
        ax.legend(fontsize=8, framealpha=0.7)

    fig.suptitle("Training Loss Curves — CIFAR-10  (100 epochs)\n"
                 "Solid = Generator   Dashed = Discriminator",
                 fontsize=13, fontweight="bold", y=1.01)
    plt.tight_layout()
    save(fig, "08_loss_curves_cifar10")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 9 — FID Curve over Epochs (simulated)
#          Replace with real FID checkpoints from your CSVs
# ══════════════════════════════════════════════════════════════════════════════
def plot_fid_curves():
    checkpoints = np.arange(10, 101, 10)
    np.random.seed(7)
    # target final FID from your results
    final_fids = dict(zip(LOSS_ORDER, df_c["Best_FID"]))

    fig, ax = plt.subplots(figsize=(11, 6))
    for loss in LOSS_ORDER:
        f_end = final_fids[loss]
        start = f_end * np.random.uniform(3.5, 6)
        curve = start * np.exp(-np.linspace(0, 2.5, len(checkpoints)))
        curve += np.random.randn(len(checkpoints)) * f_end * 0.05
        curve = np.clip(curve, f_end * 0.95, None)
        lw = 2.5 if loss == "Hybrid" else 1.5
        ls = "-"  if loss == "Hybrid" else "--"
        ax.plot(checkpoints, curve, color=PALETTE[loss],
                lw=lw, ls=ls, label=loss, marker="o",
                markersize=4 if loss != "Hybrid" else 6)

    ax.set_xlabel("Epoch", fontsize=12)
    ax.set_ylabel("FID Score  (↓ lower is better)", fontsize=12)
    ax.set_title("FID Score Over Training — CIFAR-10",
                 fontsize=14, fontweight="bold")
    ax.legend(fontsize=10, framealpha=0.9, ncol=2)
    ax.set_yscale("log")
    plt.tight_layout()
    save(fig, "09_fid_curves_cifar10")

# ══════════════════════════════════════════════════════════════════════════════
# PLOT 10 — Summary Dashboard (single figure, 4 panels)
# ══════════════════════════════════════════════════════════════════════════════
def plot_dashboard():
    fig = plt.figure(figsize=(16, 10))
    gs  = gridspec.GridSpec(2, 3, figure=fig,
                            hspace=0.42, wspace=0.38)

    # ── Panel A: FID Bar CIFAR-10
    axA = fig.add_subplot(gs[0, 0])
    axA.bar(df_c["Loss"], df_c["Best_FID"],
            color=bar_colors(df_c), edgecolor="white", width=0.6, zorder=3)
    axA.set_title("A  FID — CIFAR-10", fontweight="bold", fontsize=11)
    axA.set_xticklabels(df_c["Loss"], rotation=30, ha="right", fontsize=8)
    axA.set_ylabel("FID ↓")

    # ── Panel B: FID Bar EuroSAT
    axB = fig.add_subplot(gs[0, 1])
    axB.bar(df_e["Loss"], df_e["Best_FID"],
            color=bar_colors(df_e), edgecolor="white", width=0.6,
            alpha=0.8, hatch="///", zorder=3)
    axB.set_title("B  FID — EuroSAT", fontweight="bold", fontsize=11)
    axB.set_xticklabels(df_e["Loss"], rotation=30, ha="right", fontsize=8)
    axB.set_ylabel("FID ↓")

    # ── Panel C: Mode Variance
    axC = fig.add_subplot(gs[0, 2])
    x = np.arange(len(LOSS_ORDER))
    w = 0.35
    axC.bar(x - w/2, df_c["Mode_Var"], w, color=COLORS,
            edgecolor="white", label="CIFAR-10")
    axC.bar(x + w/2, df_e["Mode_Var"], w, color=COLORS,
            edgecolor="white", alpha=0.5, hatch="///", label="EuroSAT")
    axC.set_xticks(x)
    axC.set_xticklabels(LOSS_ORDER, rotation=30, ha="right", fontsize=8)
    axC.set_title("C  Mode Variance ↑", fontweight="bold", fontsize=11)
    axC.legend(fontsize=8)

    # ── Panel D: Scatter FID vs Diversity
    axD = fig.add_subplot(gs[1, 0:2])
    for _, row in df_c.iterrows():
        c   = PALETTE[row["Loss"]]
        sz  = 300 if row["Loss"] == "Hybrid" else 120
        mrk = "*" if row["Loss"] == "Hybrid" else "o"
        axD.scatter(row["Best_FID"], row["Mode_Var"],
                    color=c, s=sz, marker=mrk,
                    edgecolors="white", lw=0.8, zorder=5)
        axD.annotate(row["Loss"], (row["Best_FID"], row["Mode_Var"]),
                     textcoords="offset points", xytext=(5, 4),
                     fontsize=8.5, color=c, fontweight="bold")
    axD.set_xlabel("FID ← lower is better", fontsize=10)
    axD.set_ylabel("Mode Variance ↑ more diverse", fontsize=10)
    axD.set_title("D  Quality–Diversity Trade-off (CIFAR-10)",
                  fontweight="bold", fontsize=11)

    # ── Panel E: Ranking summary text
    axE = fig.add_subplot(gs[1, 2])
    axE.axis("off")
    summary = (
        "Key Findings\n"
        "─────────────────────────\n"
        "CIFAR-10\n"
        "  #1 FID       WGAN-GP   58.86\n"
        "  #2 FID       Hybrid    61.34\n"
        "  #1 Diversity Hybrid    0.298\n\n"
        "EuroSAT\n"
        "  #1 FID       LSGAN     39.91\n"
        "  #2 FID       Std GAN   40.90\n"
        "  #1 Diversity Hybrid    0.092\n\n"
        "Hybrid: best FID+Diversity\n"
        "balance across both datasets."
    )
    axE.text(0.05, 0.95, summary, transform=axE.transAxes,
             fontsize=9.5, verticalalignment="top",
             fontfamily="monospace",
             bbox=dict(boxstyle="round,pad=0.5",
                       facecolor="#E1F5EE", edgecolor="#1D9E75",
                       alpha=0.9))
    axE.set_title("E  Summary", fontweight="bold", fontsize=11)

    fig.suptitle("GAN Loss Function Comparison — Summary Dashboard",
                 fontsize=16, fontweight="bold", y=1.01)
    save(fig, "10_summary_dashboard")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("Generating plots...\n")
    plot_fid_bar()             # 01
    plot_mode_var_bar()        # 02
    plot_pareto_scatter()      # 03
    plot_grouped_fid()         # 04
    plot_radar()               # 05
    plot_heatmap()             # 06
    plot_ranking_table()       # 07
    plot_loss_curves_simulated()  # 08
    plot_fid_curves()          # 09
    plot_dashboard()           # 10
    print("\nAll 10 plots saved to ./plots/")
    print("\nNOTE: Plots 08 and 09 use simulated curves.")
    print("      Upload your CSV files and replace the data loading")
    print("      sections in plot_loss_curves_simulated() and")
    print("      plot_fid_curves() with pd.read_csv() calls.")
